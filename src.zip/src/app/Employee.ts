 export interface Employee
{
employeeid:number;
employeename:string;
phone:number;
email:string;

}