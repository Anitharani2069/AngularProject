import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
//import { Observable } from '../../node_modules/rxjs';
import { Employee } from './Employee';



@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  constructor(private _http:HttpClient) { }

  url:string='/assets/data/Employee.json';
 /* getAllEmployees():Observable<Employee[]>
{
  return this._http.get<Employee[]>(this.url)
}*/

}
