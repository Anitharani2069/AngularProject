import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product} from './product';
import {ActivatedRoute} from '../../../node_modules/@angular/router';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
 uname: string;
 constructor(private service: ProductService, private route: ActivatedRoute) {
  route.params.subscribe(params => this.uname = params['uname']);
  }

  proList: Product[];
  ngOnInit() {

  this.getAllProducts();
  }

  getAllProducts() {
  this.service.getAllProducts().subscribe(data => this.proList = data);
  }

 }
