import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product/product';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  searchList: Product[];
  searchdetails: Product[];

  constructor(private search: ProductService) { }

  ngOnInit() {
    this.getAllProducts();
  }

  getAllProducts() {
    this.search.getAllProducts().subscribe(data => this.searchList = data);

  }
    searching(data) {
    let j = 0;
   // this.searchdetails[]=[];
      this.searchdetails =[];
    for(let i= 0; i< this.searchList.length; i++) {
       if(data.value.name == this.searchList[i].name) {
         this.searchdetails[j] = this.searchList[i];
     }
     }

   }


}
