

export interface Employee{
    eid:Number;
    ename:string;
    salary:Number;
}