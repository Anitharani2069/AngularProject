import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AppRoutingModule} from './app-routing.module';
import {RouterModule,Routes} from '@angular/router';
import {HttpClientModule,HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms'


import { AppComponent } from './app.component';
import { SerachFormComponent } from './serach-form/serach-form.component';
import { ProductListComponent } from './product-list/product-list.component';

const routes:Routes=[
  {path:'search',component:SerachFormComponent},
  {path:'productlist',component:ProductListComponent}
  ]


@NgModule({
  declarations: [
    AppComponent,
    SerachFormComponent,
    ProductListComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule

    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
