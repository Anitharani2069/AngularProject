import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import {Products} from '../products';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private service:ProductsService) { }

  ngOnInit() {
    this.getAllProduct();
  }
product:Products[];

getAllProduct()
{
    this .service.getAllProducts().subscribe(data=>this.product=data);
}
}
