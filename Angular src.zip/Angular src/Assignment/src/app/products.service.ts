import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Products } from './products';



@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private _http:HttpClient) { }

  url:string='/assets/data/products.json';

  getAllProducts():Observable<Products[]>
{
  return this._http.get<Products[]>(this.url)
}
}
